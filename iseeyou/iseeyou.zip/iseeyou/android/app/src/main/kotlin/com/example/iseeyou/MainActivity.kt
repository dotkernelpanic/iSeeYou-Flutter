package com.example.iseeyou

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
